#!/bin/bash

\COPY $1 FROM '$2' DELIMITER ',';
